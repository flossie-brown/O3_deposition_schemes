# Physical constants

VON_KARMAN = 0.4       # von Kármán constant (-)
GRAVITY = 9.80616      # gravitational acceleration (m s-2)
CP = 1004.64           # specific heat capacity of dry air (J kg-1 K-1)
RHO = 1.225            # air density (kg m-3)

# Numerical parameters
USTAR_MIN = 0.15       # minimum friction velocity (m s-1)

# Boundary layer resistance parameters
SC = 0.2               # Schmidt number
PR = 0.14              # Prandtl number

#------------------------------------
#     photosynthesis constants
#------------------------------------

# Assumed atmospheric pressure (Pa)
Patm = 101325.0

# Michaelis-Menten constant for carboxylation at 25°C (Pa)
KC_25 = 404.9e-6 * Patm

# Michaelis-Menten constant for oxygenation at 25°C (Pa)
KO_25 = 278.4e-3 * Patm

# CO2 compensation point at 25°C (Pa)
GAMMASTAR_25 = 42.75e-6 * Patm

# Intercellular oxygen partial pressure (Pa)
OI = 0.209 * Patm