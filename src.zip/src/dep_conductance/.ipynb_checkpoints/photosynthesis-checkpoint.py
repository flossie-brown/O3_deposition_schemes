#------------------------------------
#------------------------------------
#
#    Photosynthesis
#
#------------------------------------
#------------------------------------

import numpy as np
import math

from .constants import KC_25, KO_25, GAMMASTAR_25, OI, R_GAS

#------------------------------------------------------------------------
#    Solar declination angle
#------------------------------------------------------------------------

def decl(n_day):
    """
    Calculate solar declination angle (radians).

    Parameters
    ----------
    n_day : float or array
        Day of year (1-365/366).

    Returns
    -------
    Solar declination angle (radians).
    """

    epsilon = np.deg2rad(23.44)
    ecc = 0.0167

    ang1 = 360 / 365.24 * (n_day - 2)
    ang2 = 360 / 365.24 * (n_day + 10) + 360 / np.pi * ecc * np.sin(np.deg2rad(ang1))

    declin = np.arcsin(
        np.sin(-epsilon) * np.cos(np.deg2rad(ang2))
    )

    return declin


#------------------------------------------------------------------------
#    Cosine of solar zenith angle
#------------------------------------------------------------------------

def cosSZA(lat, hour, n_day):
    """
    Calculate cosine of solar zenith angle.

    Parameters
    ----------
    lat : float or array
        Latitude (degrees, positive north).
    n_day : float or array
        Day of year (1-365/366).
    hour : float or array
        UTC decimal hour (0-24).

    Returns
    -------
    Cosine of solar zenith angle (dimensionless).
    """

    lat_rad = np.deg2rad(lat)

    # Solar declination
    declin = decl(n_day)

    # Solar hour angle (radians)
    hour_angle = np.deg2rad(15 * (np.asarray(hour) - 12))

    # Cosine of solar zenith angle
    cos_SZA = (
        np.sin(lat_rad) * np.sin(declin)
        + np.cos(lat_rad) * np.cos(declin) *np.cos(hour_angle)
    )

    # Set invalid values to NaN
    cos_SZA = np.where(
        np.isfinite(cos_SZA),
        cos_SZA,
        np.nan
    )

    # Below the horizon
    return np.maximum(cos_SZA, 0.001)

#------------------------------------------------------------------------
#    Dimensionless soil moisture stress factor
#------------------------------------------------------------------------

def betat(sm, sm_wilt, sm_crit):
    """
    Calculate the soil moisture stress factor (beta_t).

    Assumes a linear increase in soil moisture availability between
    the wilting point and critical soil moisture.

    Parameters
    ----------
    sm : float or array
        Volumetric soil moisture (m3 m-3).
    sm_wilt : float or array
        Soil moisture at wilting point (m3 m-3).
    sm_crit : float or array
        Critical soil moisture above which there is no water stress
        (m3 m-3).

    Returns
    -------
    float or array
        Soil moisture stress factor (dimensionless, 0-1).
    """
    sm = np.asarray(sm)
    sm_wilt = np.asarray(sm_wilt)
    sm_crit = np.asarray(sm_crit)

    if np.any(sm_crit <= sm_wilt):
        raise ValueError("sm_crit must be greater than sm_wilt.")

    b_t = np.where(
        sm >= sm_crit,
        1.0,
        np.where(
            sm > sm_wilt,
            (sm - sm_wilt) / (sm_crit - sm_wilt),
            0.0
        )
    )

    return b_t.item() if b_t.ndim == 0 else b_t


#------------------------------------
#      Light-dependent functions
#------------------------------------

def LAI_sun(kb, LAI):
    """
    Calculate sunlit leaf area index.

    Parameters
    ----------
    kb : float or array
        Direct-beam extinction coefficient (dimensionless).
    LAI : float or array
        Total leaf area index (m2 m-2).

    Returns
    -------
    float or array
        Sunlit leaf area index (m2 m-2).
    """
    return -np.expm1(-kb * LAI) / kb


def LAI_sha(kb, LAI):
    """
    Calculate shaded leaf area index.

    Parameters
    ----------
    kb : float or array
        Direct-beam extinction coefficient (dimensionless).
    LAI : float or array
        Total leaf area index (m2 m-2).

    Returns
    -------
    float or array
        Shaded leaf area index (m2 m-2).
    """
    return LAI - LAI_sun(kb, LAI)

def N_LAI_sun(kn, kb, LAI):
    """
    Calculate nitrogen-weighted sunlit leaf area index.

    Parameters
    ----------
    kn : float or array
        Nitrogen extinction coefficient (dimensionless).
    kb : float or array
        Direct-beam extinction coefficient (dimensionless).
    LAI : float or array
        Total leaf area index (m2 m-2).

    Returns
    -------
    float or array
        Nitrogen-weighted sunlit leaf area index (m2 m-2).
    """
    return (1 - np.exp(-(kn + kb) * LAI)) / (kn + kb)


def N_LAI_sha(kn, kb, LAI):
    """
    Calculate nitrogen-weighted shaded leaf area index.

    Parameters
    ----------
    kn : float or array
        Nitrogen extinction coefficient (dimensionless).
    kb : float or array
        Direct-beam extinction coefficient (dimensionless).
    LAI : float or array
        Total leaf area index (m2 m-2).

    Returns
    -------
    float or array
        Nitrogen-weighted shaded leaf area index (m2 m-2).
    """
    N_profile = (1 - np.exp(-kn * LAI)) / kn
    return N_profile - N_LAI_sun(kn, kb, LAI)


#------------------------------------
#      2-stream functions
#------------------------------------

def Iabs_dir(
    LAI,
    kb,
    lat=1,
    hour=12,
    n_day=180,
    x_l = 0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat = 0.15,
    alpha_soil_dry = 0.26,
    theta0=0.1
):
    """
    Calculate the absorption of direct and diffuse radiation by vegetation
    using the two-stream approximation.

    Parameters
    ----------
    LAI : float or array
        Total leaf area index (m2 m-2). Required.
    kb : float,  Required.
        Direct-beam extinction coefficient (dimensionless).
    lat : float or array, default=0.0
        Latitude (degrees).
    lon : float or array, default=0.0
        Longitude (degrees).
    n_day : float or array, default=180
        Day/time input required by cosSZA().
    x_l : float, default=0.25
        Leaf angle distribution parameter (dimensionless).
    alpha : float, default=0.1
        Leaf reflectance (dimensionless).
    tau : float, default=0.05
        Leaf transmittance (dimensionless).
    alpha_soil_sat : float, default=0.15
        Soil albedo under saturated conditions.
    alpha_soil_dry : float, default=0.26
        Soil albedo under dry conditions.
    theta0 : float or array, default=0.1
        Soil moisture parameter used to calculate ground albedo.

    Returns
    -------
    tuple
        I_beam_dir : Absorption of direct beam radiation by vegetation.
        I_beam_dif : Absorption of direct-beam radiation scattered into diffuse.
        I_diff : Absorption of diffuse radiation.

        All values are fractions of incident radiation (0-1).
    """

    # Solar zenith angle
    mu = cosSZA(lat, hour, n_day)

    # Leaf angle distribution
    chi_l = np.clip(x_l, -0.4, 0.6)

    phi1 = 0.5 - 0.633 * chi_l - 0.33 * chi_l**2
    phi2 = 0.877 * (1 - 2 * phi1)

    # Relative projected area of leaves and stems
    G_mu = phi1 + phi2 * mu

    # Average inverse diffuse optical depth
    mu_bar = (1 / phi2) * (
        1 - (phi1 / phi2) * np.log((phi1 + phi2) / phi1)
    )

    # Scattering coefficient
    omega = alpha + tau

    # Cosine of mean leaf inclination angle
    cos_thetabar = 0.5 * (1 + x_l)

    # Upscatter parameters
    # for diffuse radiation:
    omega_beta = 0.5 * (alpha + tau + (alpha - tau) * cos_thetabar**2)

    # for direct radiation:
    omega_beta0 = (
        (1 + mu_bar * kb) / (mu_bar * kb) * (omega / 2) * G_mu / (mu * phi2 + G_mu)
        * (1 - mu * phi1 / (mu * phi2 + G_mu) * np.log((mu * phi1 + mu * phi2 + G_mu)/ (mu * phi1)))
    )

    # Ground albedo
    Delta = np.maximum(0, 0.11 - 0.40 * theta0)
    alpha_g = np.minimum(alpha_soil_sat + Delta, alpha_soil_dry)

    # Two-stream approximation parameters
    b = 1 - omega + omega_beta
    cc = omega_beta
    d = omega_beta0 * mu_bar * kb
    f = omega * mu_bar * kb - omega_beta0 * mu_bar * kb
    h = np.sqrt(b**2 - cc**2) / mu_bar
    sigma = (mu_bar * kb)**2 + cc**2 - b**2

    u1 = b - cc / alpha_g
    u2 = b - cc * alpha_g
    u3 = f + cc * alpha_g

    s1 = np.exp(-np.minimum(h * LAI, 40))
    s2 = np.exp(-np.minimum(kb * LAI, 40))

    p1 = b + mu_bar * h
    p2 = b - mu_bar * h
    p3 = b + mu_bar * kb
    p4 = b - mu_bar * kb

    d1 = (p1 * (u1 - mu_bar * h) / s1- p2 * (u1 + mu_bar * h) * s1)
    d2 = ((u2 + mu_bar * h) / s1 - (u2 - mu_bar * h) * s1)

    h1 = -d * p4 - cc * f
    h2 = (1 / d1) * ((d - p3 * h1 / sigma) * (u1 - mu_bar * h) / s1
        - p2 * (d - cc - (h1 / sigma) * (u1 + mu_bar * kb)) * s2)
    h3 = (-1 / d1) * ((d - p3 * h1 / sigma) * (u1 + mu_bar * h) * s1
        - p1 * ( d - cc - (h1 / sigma) * (u1 + mu_bar * kb)) * s2)
    h4 = -f * p3 - cc * d
    h5 = (-1 / d2) * ((h4 / sigma) * (u2 + mu_bar * h) / s1 + (u3 - (h4 / sigma) * (u2 - mu_bar * kb)) * s2)
    h6 = (1 / d2) * ((h4 / sigma) * (u2 - mu_bar * h) * s1 + (u3 - (h4 / sigma) * (u2 - mu_bar * kb)) * s2)
    h7 = (cc / d1) * (u1 - mu_bar * h) / s1
    h8 = (-cc / d1) * (u1 + mu_bar * h) * s1
    h9 = (1 / d2) * (u2 + mu_bar * h) / s1
    h10 = (-1 / d2) * (u2 - mu_bar * h) * s1

    # Direct beam fluxes absorbed by vegetation per unit incident flux (0-1):
    I_beam_up = h1 / sigma + h2 + h3
    I_beam_down = ((h4 / sigma) * np.exp(-kb * LAI)+ h5 * s1+ h6 / s1)
    I_beam = (1 - I_beam_up- (1 - alpha_g) * I_beam_down- (1 - alpha_g) * np.exp(-kb * LAI))

    # Absorption of direct beam radiation into direct and dir2dif (0-1):
    I_beam_dir = (1 - omega) * (1 - np.exp(-kb * LAI))
    I_beam_dif = I_beam - I_beam_dir

    # Diffuse fluxes per unit incident diffuse flux (0-1):
    I_diff_down = h9 * s1 + h10 / s1
    I_diff_up = h7 + h8
    I_diff = 1 - I_diff_up - (1 - alpha_g) * I_diff_down

    return I_beam_dir, I_beam_dif, I_diff

def phi(
    PAR,
    LAI,
    kb,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l = 0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat = 0.15,
    alpha_soil_dry = 0.26,
    theta0=0.1,
):
    """
    Calculate absorbed PAR per unit ground area for sunlit and shaded leaves.

       Parameters
    ----------
    PAR : float or array  Required.
        Incoming photosynthetically active radiation (W m-2)
    LAI : float or array
        Total leaf area index (m2 m-2). Required.
    kb : float,  Required.
        Direct-beam extinction coefficient (dimensionless).
    diff_frac: float, default = 0.4
        fraction of incoming PAR that is diffuse  (dimensionless).


    Returns
    -------
    tuple
        phi_sun : Absorbed PAR for sun leaves (W m-2 ground area).
        phi_sha : Absorbed PAR for shade leaves (W m-2 ground area).

    """

    if np.any(np.asarray(LAI) <= 0):
        raise ValueError("LAI must be greater than zero.")

    # Sunlit and shaded LAI fractions to partition light between fractions
    L_sun = LAI_sun(kb, LAI)
    L_sha = LAI_sha(kb, LAI)

    fsun = L_sun / LAI
    fsha = L_sha / LAI

    # Direct and diffuse incident PAR
    S_dir = PAR * (1 - diff_frac)
    S_diff = PAR * diff_frac

    # Canopy absorption fractions
    Iabs_dir2dir, Iabs_dir2dif, Iabs_diff = Iabs_dir( LAI, kb, 
    lat, hour, n_day, x_l, alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0)

   # Absorbed PAR available for sun and shade leaves (W m^-2 ground area):
    phi_sun = ((Iabs_dir2dir+Iabs_dir2dif*fsun)*S_dir + Iabs_diff*S_diff*fsun)
    phi_sha = (Iabs_dir2dif*S_dir*fsha + Iabs_diff*S_diff*fsha)


    return phi_sun, phi_sha

#------------------------------------
#     Temperature dependencies
#------------------------------------

def f_Tv(T_v, DH_a):
    """
    Calculate the activation energy temperature response.

    Parameters
    ----------
    T_v : float or array
        Vegetation temperature (K).
    DH_a : float
        Activation energy (J mol-1).

    Returns
    -------
    float or array
        Dimensionless temperature response.
    """
    term1 = DH_a / (298.15 * R_GAS)
    term2 = 1 - (298.15 / T_v)

    return np.exp(term1 * term2)


def f_H_Tv(T_v, DH_d, DS):
    """
    Calculate the high-temperature deactivation response.

    Parameters
    ----------
    T_v : float or array
        Vegetation temperature (K).
    DH_d : float
        Deactivation energy (J mol-1).
    DS : float
        Entropy term (J mol-1 K-1).

    Returns
    -------
    float or array
        Dimensionless temperature response.
    """
    term1 = (298.15 * DS - DH_d) / (298.15 * R_GAS)
    term2 = (DS * T_v - DH_d) / (R_GAS * T_v)

    return (1 + np.exp(term1)) / (1 + np.exp(term2))

#----------------quadroot--------------------
#find root of quadratics

def quadroot(a, b, c):
    # This function finds the roots of quadratic equation a*x^2 + b*x + c = 0.
    D = b**2 - 4*a*c
    if math.isnan(D)==True:
        x1 = np.nan
        x2 = np.nan
    else:
        if a == 0:
            # If a is exactly zero, simply solve for linear equation b*x + c = 0
            x1 = -c/b
            x2 = np.nan
        else:
                if D >= 0:
                    # Roots are real.
                    x1 = (-b+(D)**0.5)/(2*a)
                    x2 = (-b-(D)**0.5)/(2*a)
                
                else:
                    # Roots are complex.
                    x1 = complex(-b/2/a, (-D)**0.5/2/a)
                    x2 = complex(-b/2/a, -(-D)**0.5/2/a)

    return [x1, x2]

#------------------------------------
#     photosynthetic params
#------------------------------------

def Vcmax_25(Vcmax_25_0, kn, kb, LAI):
    """
    Calculate average Vcmax at 25 degrees C for sunlit or shaded leaves.

    Parameters
    ----------
    Vcmax_25_0 : float
        Vcmax at the top of the canopy (umol CO2 m-2 leaf s-1).
    kn : float
        Nitrogen extinction coefficient (dimensionless).
    kb : float
        Direct-beam extinction coefficient (dimensionless).
    LAI : float
        Total leaf area index (m2 leaf m-2 ground).


    Returns
    -------
    float
        Average Vcmax at 25 degrees C (umol CO2 m-2 ground s-1).
    """
    if np.any(np.asarray(LAI) <= 0):
        raise ValueError("LAI must be greater than zero.")

    # Nitrogen-weighted leaf area
    N_sun = N_LAI_sun(kn, kb, LAI)
    N_sha = N_LAI_sha(kn, kb, LAI)


    return Vcmax_25_0 * N_sun , Vcmax_25_0 * N_sha

def Rd_25(Vcmax_25_0, kn, kb, LAI, rd0=0.025):
    """
    Calculate mitochondrial respiration at 25°C for sunlit and shaded leaves.

    Parameters
    ----------
    rd0 : float
        Ratio of mitochondrial respiration to Vcmax at 25°C (dimensionless).
        Default = 0.025.

    Returns
    -------
    tuple
        rd_sun, rd_sha (umol CO2 m-2 ground s-1).
    """
    Vcmax_sun, Vcmax_sha = Vcmax_25(Vcmax_25_0, kn, kb, LAI)

    rd_sun = rd0 * Vcmax_sun
    rd_sha = rd0 * Vcmax_sha

    return rd_sun, rd_sha


def Jmax_25(Vcmax_25_0, kn, kb, LAI, jratio=1.76):
    """
    Calculate maximum electron transport rate at 25°C for sunlit and shaded leaves.

    Parameters
    ----------
    jratio : float
        Ratio of maximum electron transport rate to Vcmax at 25°C
        (dimensionless). Default = 1.76.

    Returns
    -------
    tuple
        jmax_sun, jmax_sha (umol electrons m-2 ground s-1).
    """
    Vcmax_sun, Vcmax_sha = Vcmax_25(Vcmax_25_0, kn, kb, LAI)

    jmax_sun = jratio * Vcmax_sun
    jmax_sha = jratio * Vcmax_sha

    return jmax_sun, jmax_sha


def I_PSII(
    PAR,
    LAI,
    kb,
    Phi_PSII=0.85,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l=0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat=0.15,
    alpha_soil_dry=0.26,
    theta0=0.1,
):
    """
    Calculate electron transport rates for sunlit and shaded leaves.

        Parameters
    ----------
    PAR : float or array
        Incident photosynthetically active radiation (W m-2).
    LAI : float or array
        Total leaf area index (m2 leaf m-2 ground).
    kb : float or array
        Direct-beam extinction coefficient (dimensionless).
    Phi_PSII : float
        Effective quantum yield of photosystem II (dimensionless).
        Default is 0.85.

    Returns
    -------
    tuple
        Sunlit and shaded electron transport rates per unit ground area
        (umol electrons m-2 ground s-1).
    """

    phi_sun, phi_sha = phi(
        PAR, LAI, kb, diff_frac, lat, hour, n_day, x_l,
        alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0
    )

    I_PSII_sun = 0.5 * Phi_PSII * 4.6 * phi_sun
    I_PSII_sha = 0.5 * Phi_PSII * 4.6 * phi_sha

    return I_PSII_sun, I_PSII_sha


def V_cmax(
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Vcmax,
    DH_d_Vcmax,
    DS_Vcmax,
    sm, sm_wilt, sm_crit
):
    """
    Calculate maximum carboxylation rate adjusted for temperature
    and soil water stress.

    Parameters
    ----------
    DH_a_Vcmax : float
        Activation energy for Vcmax (J mol-1).
    DH_d_Vcmax : float
        Deactivation energy for Vcmax (J mol-1).
    DS_Vcmax : float
        Entropy term for Vcmax (J mol-1 K-1).

    Returns
    -------
    tuple
        Vcmax_sun, Vcmax_sha (umol CO2 m-2 ground s-1).

    """
    
    Vcmax_25_sun, Vcmax_25_sha = Vcmax_25(Vcmax_25_0, kn, kb, LAI)

    f_temp = (f_Tv(T_v, DH_a_Vcmax)* f_H_Tv(T_v, DH_d_Vcmax, DS_Vcmax))

    beta_t = betat(sm, sm_wilt, sm_crit)

    Vcmax_sun = Vcmax_25_sun * f_temp * beta_t
    Vcmax_sha = Vcmax_25_sha * f_temp * beta_t

    return Vcmax_sun, Vcmax_sha


def J_max(
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax,
    DH_d_Jmax,
    DS_Jmax,
    jratio = 1.76
):
    """
    Calculate maximum electron transport rate adjusted for temperature.

    Parameters
    ----------
    DH_a_Jmax : float
        Activation energy for Jmax (J mol-1).
    DH_d_Jmax : float
        Deactivation energy for Jmax (J mol-1).
    DS_Jmax : float
        Entropy term for Jmax (J mol-1 K-1).
    jratio : float
        Ratio of Jmax to Vcmax at 25°C (dimensionless). Default = 1.76.

    Returns
    -------
    tuple
        jmax_sun, jmax_sha (umol electrons m-2 ground s-1).
    """
    Jmax_25_sun, Jmax_25_sha = Jmax_25(Vcmax_25_0, kn, kb, LAI, jratio)

    f_temp = (f_Tv(T_v, DH_a_Jmax)* f_H_Tv(T_v, DH_d_Jmax, DS_Jmax))
    
    Jmax_sun = Jmax_25_sun * f_temp
    Jmax_sha = Jmax_25_sha * f_temp

    return Jmax_sun, Jmax_sha

def R_d(
    Vcmax_25_0, kn, kb, LAI, T_v,
    sm, sm_wilt, sm_crit,
    DH_a_Rd = 46390.0,
    DH_d_Rd =150650.0,
    DS_Rd = 490.0,
    rd0 = 0.025
):
    """
    Calculate mitochondrial respiration adjusted for temperature
    and soil water stress.

    Parameters
    ----------
    DH_a_Rd : float
        Activation energy for Rd (J mol-1). Default = 46390.
    DH_d_Rd : float
        Deactivation energy for Rd (J mol-1). Default = 150650.
    DS_Rd : float
        Entropy term for Rd (J mol-1 K-1). Default = 490.
    rd0 : float
        Ratio of Rd to Vcmax at 25°C (dimensionless). Default = 0.025.

    Returns
    -------
    tuple
        rd_sun, rd_sha (umol CO2 m-2 ground s-1).
    """

    Rd_25_sun, Rd_25_sha = Rd_25(Vcmax_25_0, kn, kb, LAI, rd0)

    f_temp = (f_Tv(T_v, DH_a_Rd)* f_H_Tv(T_v, DH_d_Rd, DS_Rd))

    beta_t = betat(sm, sm_wilt, sm_crit)

    Rd_sun = Rd_25_sun * f_temp * beta_t
    Rd_sha = Rd_25_sha * f_temp * beta_t

    return Rd_sun, Rd_sha

#------------------------------------
#     Electron transport rate
#------------------------------------

def J_roots(
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax,
    DH_d_Jmax,
    DS_Jmax,
    PAR,
    Theta_PSII=0.7,
    Phi_PSII=0.85,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l=0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat=0.15,
    alpha_soil_dry=0.26,
    theta0=0.1,
    jratio=1.76
):
    """
    Calculate the two roots of the non-rectangular hyperbola for
    electron transport rate in sunlit and shaded canopy fractions.

    Returns
    -------
    tuple
        Roots for sunlit and shaded electron transport rates
        (umol electrons m-2 ground s-1).
    """
    I_sun, I_sha = I_PSII(PAR, LAI,  kb, Phi_PSII, diff_frac, lat, hour, n_day,
    x_l, alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0)

    Jmax_sun, Jmax_sha = J_max(
        Vcmax_25_0, kn, kb, LAI, T_v,
        DH_a_Jmax, DH_d_Jmax, DS_Jmax, jratio
    )

    J_roots_sun = quadroot(
        Theta_PSII, b=-(I_sun + Jmax_sun), c=I_sun * Jmax_sun
    )

    J_roots_sha = quadroot(
        Theta_PSII, b=-(I_sha + Jmax_sha), c=I_sha * Jmax_sha
    )

    return J_roots_sun, J_roots_sha


def J(
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax,
    DH_d_Jmax,
    DS_Jmax,
    PAR,
    Theta_PSII=0.7,
    Phi_PSII=0.85,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l=0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat=0.15,
    alpha_soil_dry=0.26,
    theta0=0.1, jratio=1.76
):
    """
    Calculate electron transport rate for sunlit and shaded
    canopy fractions using the smaller root of the non-rectangular
    hyperbola.

    Returns
    -------
    tuple
        J_sun, J_sha (umol electrons m-2 ground s-1).
    """
    J_roots_sun, J_roots_sha = J_roots( Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax, DH_d_Jmax, DS_Jmax, PAR,
    Theta_PSII, Phi_PSII , diff_frac, lat, hour, n_day,
    x_l, alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0, jratio
    )

    J_sun = min(J_roots_sun)
    J_sha = min(J_roots_sha)

    return J_sun, J_sha


#------------------------------------
#     Photosynthesis constants
#------------------------------------

def Gamma_star(T_v):
    """
    Calculate the CO2 compensation point in the absence of mitochondrial
    respiration, adjusted for temperature.

    Parameters
    ----------
    T_v : float or array
        Vegetation temperature (K).

    Returns
    -------
    float or array
        CO2 compensation point (Pa).
    """
    return GAMMASTAR_25 * f_Tv(T_v, 37830)


def K_c(T_v):
    """
    Calculate the Michaelis-Menten constant for carboxylation,
    adjusted for temperature.

    Parameters
    ----------
    T_v : float or array
        Vegetation temperature (K).

    Returns
    -------
    float or array
        Michaelis-Menten constant for CO2 (Pa).
    """
    return KC_25 * f_Tv(T_v, 79430)


def K_o(T_v):
    """
    Calculate the Michaelis-Menten constant for oxygenation,
    adjusted for temperature.

    Parameters
    ----------
    T_v : float or array
        Vegetation temperature (K).

    Returns
    -------
    float or array
        Michaelis-Menten constant for O2 (Pa).
    """
    return KO_25 * f_Tv(T_v, 36380)

#------------------------------------
#     Photosynthesis limiting rates
#------------------------------------

def A_c(
    c_i,
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Vcmax,
    DH_d_Vcmax,
    DS_Vcmax,
    sm, sm_wilt, sm_crit
):
    """
    Calculate Rubisco-limited photosynthesis for sunlit and shaded
    canopy fractions.

    Parameters
    ----------
    c_i : float or array
        Intercellular CO2 partial pressure (Pa).

    Returns
    -------
    tuple
        A_c_sun, A_c_sha (umol CO2 m-2 ground s-1).
    """
    Gamma = Gamma_star(T_v)
    Kc = K_c(T_v)
    Ko = K_o(T_v)

    upper_term = c_i - Gamma
    lower_term = c_i + Kc * (1 + OI / Ko)
    factor = upper_term / lower_term

    Vcmax_sun, Vcmax_sha = V_cmax(
        Vcmax_25_0, kn, kb, LAI, T_v,
        DH_a_Vcmax, DH_d_Vcmax, DS_Vcmax,
        sm, sm_wilt, sm_crit
    )

    A_c_sun = Vcmax_sun * factor
    A_c_sha = Vcmax_sha * factor

    return A_c_sun, A_c_sha


def A_j(
    c_i,
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax,
    DH_d_Jmax,
    DS_Jmax,
    PAR,
    Theta_PSII=0.7,
    Phi_PSII=0.85,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l=0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat=0.15,
    alpha_soil_dry=0.26,
    theta0=0.1, jratio=1.76
):
    """
    Calculate RuBP-regeneration-limited photosynthesis for sunlit
    and shaded canopy fractions.

    Parameters
    ----------
    c_i : float or array
        Intercellular CO2 partial pressure (Pa).

    Returns
    -------
    tuple
        A_j_sun, A_j_sha (umol CO2 m-2 ground s-1).
    """
    Gamma = Gamma_star(T_v)

    J_sun, J_sha = J( Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax, DH_d_Jmax, DS_Jmax, PAR,
    Theta_PSII, Phi_PSII , diff_frac, lat, hour, n_day,
    x_l, alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0, jratio
    )

    factor = (c_i - Gamma) / (4 * c_i + 8 * Gamma)

    A_j_sun = J_sun * factor
    A_j_sha = J_sha * factor

    return A_j_sun, A_j_sha

#------------------------------------
#     Net photosynthesis
#------------------------------------

def photo(
    c_i,
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Vcmax,
    DH_d_Vcmax,
    DS_Vcmax,
    DH_a_Jmax,
    DH_d_Jmax,
    DS_Jmax,
    PAR,
    Theta_PSII=0.7,
    Phi_PSII=0.85,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l=0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat=0.15,
    alpha_soil_dry=0.26,
    theta0=0.1, jratio=1.76,
    Theta_cj=0.98,
    sm=0.3,
    sm_wilt=0.1,
    sm_crit=0.3
):
    """
    Calculate gross canopy photosynthesis for sunlit and shaded
    canopy fractions.

    Returns
    -------
    tuple
        A_sun, A_sha (umol CO2 m-2 ground s-1).
    """
    A_c_sun, A_c_sha = A_c(
        c_i,
        Vcmax_25_0, kn, kb, LAI, T_v,
        DH_a_Vcmax, DH_d_Vcmax, DS_Vcmax,
        sm, sm_wilt, sm_crit
    )

    A_j_sun, A_j_sha = A_j(
        c_i, Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Jmax, DH_d_Jmax, DS_Jmax, PAR,
    Theta_PSII, Phi_PSII , diff_frac, lat, hour, n_day,
    x_l, alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0, jratio
    )

    A_c_sun = max(A_c_sun, 0)
    A_c_sha = max(A_c_sha, 0)
    A_j_sun = max(A_j_sun, 0)
    A_j_sha = max(A_j_sha, 0)

    A_sun_roots = quadroot(
        Theta_cj,
        b=-(A_c_sun + A_j_sun),
        c=A_c_sun * A_j_sun
    )

    A_sha_roots = quadroot(
        Theta_cj,
        b=-(A_c_sha + A_j_sha),
        c=A_c_sha * A_j_sha
    )

    A_sun = min(A_sun_roots)
    A_sha = min(A_sha_roots)

    return A_sun, A_sha


def A_n(
    c_i,
    Vcmax_25_0, kn, kb, LAI, T_v,
    DH_a_Vcmax,
    DH_d_Vcmax,
    DS_Vcmax,
    DH_a_Jmax,
    DH_d_Jmax,
    DS_Jmax,
    PAR,
    Theta_PSII=0.7,
    Phi_PSII=0.85,
    diff_frac=0.4,
    lat=1,
    hour=12,
    n_day=180,
    x_l=0.25,
    alpha=0.1,
    tau=0.05,
    alpha_soil_sat=0.15,
    alpha_soil_dry=0.26,
    theta0=0.1, jratio=1.76,
    Theta_cj=0.98,
    sm=0.3,
    sm_wilt=0.1,
    sm_crit=0.3,
    rd0=0.025,
    DH_a_Rd=46390.0,
    DH_d_Rd=150650.0,
    DS_Rd=490.0
):
    """
    Calculate net canopy photosynthesis for sunlit and shaded
    canopy fractions.

    Returns
    -------
    tuple
        A_n_sun, A_n_sha (umol CO2 m-2 ground s-1).
    """
    A_sun, A_sha = photo(
        c_i,
        Vcmax_25_0, kn, kb, LAI, T_v,
        DH_a_Vcmax, DH_d_Vcmax, DS_Vcmax,
        DH_a_Jmax, DH_d_Jmax, DS_Jmax,
        PAR,
        Theta_PSII, Phi_PSII,
        diff_frac, lat, hour, n_day, x_l,
        alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0, jratio,
        Theta_cj, sm, sm_wilt, sm_crit
    )

    Rd_sun, Rd_sha = R_d(
        Vcmax_25_0, kn, kb, LAI, T_v,
        sm, sm_wilt, sm_crit,
        DH_a_Rd, DH_d_Rd, DS_Rd,
        rd0
    )

    A_n_sun = A_sun - Rd_sun
    A_n_sha = A_sha - Rd_sha

    return A_n_sun, A_n_sha