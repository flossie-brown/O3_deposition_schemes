import numpy as np

from .constants import (
    VON_KARMAN,
    GRAVITY,
    CP,
    RHO,
    USTAR_MIN,
    SC,
    PR,
    Patm,
    R_GAS
)

from .photosynthesis import (
    betat,
    phi,
    LAI_sun,
    LAI_sha,
    decl)

#------------------------------------
#------------------------------------
#
#    Ra and Rb
#
#------------------------------------
#------------------------------------


def obk(T, ustar, H):
    """
    Calculate the Monin-Obukhov length.

    Parameters
    ----------
    T : float or array
        Surface air temperature (K).
    ustar : float or array
        Friction velocity (m s-1).
    H : float or array
        Sensible heat flux (W m-2).

    Returns
    -------
    float or array
        Monin-Obukhov length (m).
    """

    numerator = -RHO * CP * T * ustar**3
    denominator = VON_KARMAN * GRAVITY * H

    L = np.divide(
        numerator,
        denominator,
        out=np.full(np.broadcast(T, ustar, H).shape, 1e6, dtype=float),
        where=np.abs(H) > 1
    )

    return L.item() if L.ndim == 0 else L


def stability(T, ustar, H, h, z):
    """
    Calculate the dimensionless atmospheric stability parameter (zeta).

    Parameters
    ----------
    T : float or array
        Surface air temperature (K).
    ustar : float or array
        Friction velocity (m s-1).
    H : float or array
        Sensible heat flux (W m-2).
    h : float or array
        Canopy height (m).
    z : float or array
        Measurement height (m).

    Returns
    -------
    float or array
        Dimensionless stability parameter.
    """

    ustar_eff = np.maximum(ustar, USTAR_MIN)

    d = 2 * h / 3
    L = obk(T, ustar_eff, H)

    return (z - d) / L


def psi_h(T, ustar, H, h, z):
    """
    Calculate the stability correction function.

    Stable conditions:   zeta >= 0
    Unstable conditions: zeta < 0

    Returns
    -------
    float or array
        Stability correction (dimensionless).
    """

    zeta = stability(T, ustar, H, h, z)

    x = np.maximum(1 - 16 * zeta, 0)**0.25

    psi_stable = -5.0 * zeta
    psi_unstable = 2.0 * np.log((1 + x**2) / 2.0)

    return np.where(zeta >= 0, psi_stable, psi_unstable)


def Ra(T, ustar, H, h, z0, z):
    """
    Calculate aerodynamic resistance (Ra).

    Parameters
    ----------
    T : float or array
        Surface air temperature (K).
    ustar : float or array
        Friction velocity (m s-1).
    H : float or array
        Sensible heat flux (W m-2).
    h : float or array
        Canopy height (m).
    z0 : float or array
        Aerodynamic roughness length (m).
    z : float or array
        Measurement height (m).

    Returns
    -------
    float or array
        Aerodynamic resistance (s m-1).
    """

    ustar_eff = np.maximum(ustar, USTAR_MIN)

    d = 2 * h / 3

    upper = np.log((z - d) / z0)
    lower = VON_KARMAN * ustar_eff

    psi = psi_h(T, ustar_eff, H, h, z)

    ra = (upper - psi) / lower

    return ra


def Rb(ustar):
    """
    Calculate quasi-laminar boundary layer resistance (Rb).

    Based on the Schmidt and Prandtl number parameterisation.

    Parameters
    ----------
    ustar : float or array
        Friction velocity (m s-1).

    Returns
    -------
    float or array
        Boundary layer resistance (s m-1).
    """

    x = 2 / (VON_KARMAN * ustar)
    y = (SC / PR)**(2/3)

    return x * y * 0.6


#------------------------------------
#------------------------------------
#
#   Partitioning
#
#------------------------------------
#------------------------------------


def fwet_fraction(RH, RH_min=70.0, RH_max=90.0):
    """
    Calculate the fraction of wet foliage as a function of relative humidity.

    Assumes that foliage is completely dry below RH_min and completely
    wet above RH_max, with a linear transition between these thresholds.

    Parameters
    ----------
    RH : float or array
        Relative humidity (%).
    RH_min : float, optional
        Relative humidity threshold below which foliage is dry (%).
        Default is 70%.
    RH_max : float, optional
        Relative humidity threshold above which foliage is fully wet (%).
        Default is 90%.

    from Zhang et al. (2017)

    Returns
    -------
    float or array
        Fraction of wet foliage (dimensionless, 0-1).
    """
    if RH_max <= RH_min:
        raise ValueError("RH_max must be greater than RH_min.")

    f = np.clip(
        (np.asarray(RH) - RH_min) / (RH_max - RH_min),
        0,
        1
    )

    return f.item() if f.ndim == 0 else f


def molar_volume(T):
    """
    Calculate the molar volume of air using the ideal gas law.

    Parameters
    ----------
    T : float or array
        Air temperature (K).

    Returns
    -------
    float or array
        Molar volume of air (m3 mol-1).
    """
    return R_GAS * np.asarray(T) / np.asarray(Patm)


def RH_to_VPD(T, RH, VPD_min=0.05):
    """
    Calculate vapour pressure deficit (VPD) from temperature and
    relative humidity.

    Uses the Tetens equation to calculate saturation vapour pressure,
    followed by the calculation of VPD.

    A minimum VPD can be imposed to prevent excessively large
    stomatal conductance estimates in the Medlyn model at very
    low atmospheric VPD.

    Parameters
    ----------
    T : float or array
        Air temperature (K).
    RH : float or array
        Relative humidity (%).
    VPD_min : float, optional
        Minimum allowable VPD (kPa). Default is 0.05 kPa.

    Returns
    -------
    float or array
        Vapour pressure deficit (kPa).
    """
    T_c = np.asarray(T) - 273.15
    RH = np.clip(np.asarray(RH), 0, 100)
    RH_lim = np.where(RH>95, 95, RH)

    # Saturation vapour pressure (kPa)
    es = 0.61078 * np.exp(
        17.2694 * T_c / (T_c + 237.3)
    )

    # Vapour pressure deficit (kPa)
    VPD = es * (1 - RH_lim / 100)

    VPD = np.maximum(VPD, VPD_min)

    return VPD.item() if VPD.ndim == 0 else VPD

#------------------------------------
#------------------------------------
#
#   Medlyn
#
#------------------------------------
#------------------------------------

def gs_medlyn(GPP, CO2, VPD, g1_med, T, SM, sm_wilt, sm_crit, D=0.67):
    """
    Calculate stomatal conductance using the Medlyn model.

    Conductance is converted from molar units to velocity units
    using the ideal gas law.

    Parameters
    ----------
    GPP : float or array
        Gross photosynthetic assimilation rate (umol CO2 m-2 s-1).
    CO2 : float or array
        Atmospheric CO2 mole fraction (umol mol-1 or ppm).
    VPD : float or array
        Vapour pressure deficit (kPa).
    g1_med : float
        Medlyn stomatal slope parameter (kPa0.5).
    T : float or array
        Air temperature (K).
    Patm : float or array
        Atmospheric pressure (Pa).
    beta_t : float or array, optional
        Soil moisture stress factor (dimensionless, 0-1).
        Default is 1 (no soil moisture stress).
    D : float, optional
        conversion to ozne from H2o.
        Default is 0.67

    Returns
    -------
    float or array
        Stomatal conductance (m s-1).
    """

    beta_t = betat(SM, sm_wilt, sm_crit)

    # Molar stomatal conductance (mol H2O m-2 s-1)
    gs_mol = (1.6* (1 + (g1_med * np.asarray(beta_t)) / np.sqrt(VPD))* np.asarray(GPP) / np.asarray(CO2))

    # Convert molar conductance to velocity (m s-1)
    gs = gs_mol * molar_volume(T) * D

    # Ensure conductance is non-negative
    gs = np.maximum(gs, 0.0)

    return gs.item() if gs.ndim == 0 else gs

#------------------------------------
#------------------------------------
#
#   Ball_berry Model
#
#------------------------------------
#------------------------------------

def gs_bb(GPP, CO2, RH, g1_bb, T, SM, sm_wilt, sm_crit, D=0.67):
    """
    Calculate stomatal conductance using the Ball-Berry model.

    Conductance is converted from molar units to velocity units
    using the ideal gas law.

    Parameters
    ----------
    GPP : float or array
        Gross photosynthetic assimilation rate (umol CO2 m-2 s-1).
    CO2 : float or array
        Atmospheric CO2 mole fraction (umol mol-1 or ppm).
    RH : float or array
        Relative Humidity (%).
    g1_bb : float
        Ball-Berry stomatal slope parameter.
    T : float or array
        Air temperature (K).
    Patm : float or array
        Atmospheric pressure (Pa).
    beta_t : float or array, optional
        Soil moisture stress factor (dimensionless, 0-1).
        Default is 1 (no soil moisture stress).
    D : float, optional
        conversion to ozne from H2o.
        Default is 0.67

    Returns
    -------
    float or array
        Stomatal conductance (m s-1).

    """

    beta_t = betat(SM, sm_wilt, sm_crit)

    # Molar stomatal conductance (mol H2O m-2 s-1)
    gs_mol = (g1_bb * np.asarray(RH)/100)* (np.asarray(GPP) / np.asarray(CO2))

    # Convert molar conductance to velocity (m s-1)
    gs = gs_mol * molar_volume(T) * D * np.asarray(beta_t)

    # Ensure conductance is non-negative
    gs = np.maximum(gs, 0.0)

    return gs.item() if gs.ndim == 0 else gs

#------------------------------------
#------------------------------------
#
#   Jarvis
#
#------------------------------------
#------------------------------------
#
# Calculates the stomatal conductance response to environmental
# conditions using temperature, PAR, VPD and soil moisture
# response functions.
#
# References:
# UNECE CLRTAP 
Manual for modelling and mapping critical loads & levels
https://icpvegetation.ceh.ac.uk/get-involved/manuals/mapping-manual
#
# Units:
#   Stomatal conductance: mmol O3 m-2 PLA s-1
#   Temperature:          K
#   PAR:                  W m-2
#   VPD:                  kPa
#   Relative humidity:    %
#   Volumetric soil moisture:        m3 m-3
#   LAI:                  m2 leaf m-2 ground
#
#------------------------------------

# -------------------- TEMPERATURE RESPONSE --------------------

def fT(fmin, Ts, Tmax, Topt, Tmin):
    """
    Temperature response function.

    Parameters
    ----------
    fmin : float or array
        Minimum response (dimensionless).
    Ts : float or array
        Surface/leaf temperature (K).
    Tmax, Topt, Tmin : float
        Maximum, optimum and minimum temperatures (deg C).

    Returns
    -------
    ft : float or ndarray
        Temperature response (dimensionless).
    """

    T = np.asarray(Ts) - 273.15

    # Temperature response parameters
    bt = (Tmax - Topt) / (Topt - Tmin)

    # Restrict temperature to the valid range
    T_clip = np.clip(T, Tmin, Tmax)

    T1 = (T_clip - Tmin) / (Topt - Tmin)
    T2 = (Tmax - T_clip) / (Tmax - Topt)

    Tc = T1 * (T2 ** bt)

    # Apply minimum response
    ft = np.maximum(fmin, Tc)

    return ft


# -------------------- LIGHT RESPONSE --------------------

def fPAR(fmin, a, PAR, LAI, kb,
         diff_frac=0.4, lat=1, lon=1, n_day=180,
         x_l=0.25, alpha=0.1, tau=0.05,
         alpha_soil_sat=0.15, alpha_soil_dry=0.26,
         theta0=0.1):
    """
    Light response function.

    Calculates the relative response of stomatal conductance
    to absorbed PAR for sunlit and shaded leaves.

    Parameters
    ----------
    fmin : float
        Minimum response (dimensionless).
    a : float
        Empirical light response coefficient (umol-1 m2 s).
    PAR : float or array
        Incoming PAR (W m-2).
    LAI : float or array
        Leaf area index (m2 leaf m-2 ground).
    kb : float
        Canopy light extinction coefficient (dimensionless).
    diff_frac : float or array
        Diffuse fraction of incoming PAR (dimensionless).
    lat, lon : float
        Latitude and longitude (degrees).
    n_day : int
        Day of year.
    x_l, alpha, tau : float
        Canopy radiation transfer parameters.
    alpha_soil_sat, alpha_soil_dry : float
        Soil albedo under saturated and dry conditions.
    theta0 : float
        Solar zenith angle (model-defined units).

    Returns
    -------
    par_sun, par_sha : float or ndarray
        Light response for sunlit and shaded leaves
        (dimensionless).
    """

    # Absorbed PAR for sunlit and shaded leaves
    phi_sun, phi_sha = phi(
        PAR, LAI, kb, diff_frac, lat, lon, n_day, x_l,
        alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0
    )

    # Sunlit and shaded leaf area
    L_sun = LAI_sun(kb, LAI)
    L_sha = LAI_sha(kb, LAI)

    # Absorbed PAR per unit leaf area
    apar_sun = phi_sun / L_sun
    apar_sha = phi_sha / L_sha

    # Convert W m-2 to umol photons m-2 s-1
    PAR_sun_umol = apar_sun * 4.6
    PAR_sha_umol = apar_sha * 4.6

    # Light response
    par_sun = fmin + (1 - np.exp(a * PAR_sun_umol))
    par_sha = fmin + (1 - np.exp(a * PAR_sha_umol))

    return par_sun, par_sha


# -------------------- VPD RESPONSE --------------------

def fVPD(Ts, RH, k, d):
    """
    Vapour pressure deficit response function.

    Parameters
    ----------
    Ts : float or array
        Air/leaf temperature (K).
    RH : float or array
        Relative humidity (%).
    k : float
        Empirical VPD sensitivity parameter (kPa).
    d : float
        VPD response exponent (dimensionless).

    Returns
    -------
    v : float or ndarray
        VPD response (dimensionless).
    """

    vpd = RH_to_VPD(np.asarray(Ts), np.asarray(RH))

    v = 1 / (1 + (vpd / k)**d)

    return v


# -------------------- STOMATAL CONDUCTANCE --------------------

def gs_jarvis(
    gmax, fmin, PAR, Ts, RH, k, d,
    Tmax, Topt, Tmin, a,
    LAI, kb, sm, sm_wilt, sm_crit,
    diff_frac=0.4, lat=1, hour=12, n_day=180,
    x_l=0.25, alpha=0.1, tau=0.05,
    alpha_soil_sat=0.15, alpha_soil_dry=0.26,
    theta0=0.1
):
    """
    Calculate canopy-integrated stomatal conductance
    using the Jarvis multiplicative approach.

    Calculates separate conductances for sunlit and shaded
    leaves, accounting for environmental limitations from
    light, temperature, VPD and soil moisture.

    Parameters
    ----------
    gmax : float or array
        Maximum leaf stomatal conductance
        (mmol O3 m-2 leaf s-1).
    fmin : float
        Minimum environmental response (dimensionless).
    PAR : float or array
        Incoming PAR (W m-2).
    Ts : float or array
        Temperature (K).
    RH : float or array
        Relative humidity (%).
    k : float
        VPD sensitivity parameter (kPa).
    d : float
        VPD response exponent (dimensionless).
    Tmax, Topt, Tmin : float
        Maximum, optimum and minimum temperatures (deg C).
    a : float
        Empirical light response coefficient.
    LAI : float or array
        Total leaf area index (m2 m-2).
    kb : float
        Canopy light extinction coefficient.
    sm : float or array
        Volumetric soil moisture (m3 m-3).
    sm_wilt : float
        Soil moisture at wilting point (m3 m-3).
    sm_crit : float
        Soil moisture threshold for unstressed conditions
        (m3 m-3).
    diff_frac : float or array
        Diffuse fraction of incoming PAR.
    lat, lon : float
        Latitude and longitude (degrees).
    n_day : int
        Day of year.
    x_l, alpha, tau : float
        Canopy radiation transfer parameters.
    alpha_soil_sat, alpha_soil_dry : float
        Soil albedo under saturated and dry conditions.
    theta0 : float
        Solar zenith angle (model-defined units).

    Returns
    -------
    g_sun, g_sha : float or ndarray
        Sunlit and shaded canopy-integrated stomatal
        conductance (m s-1).
    """

    # Environmental response functions
    f_par_sun, f_par_sha = fPAR(
        fmin, a, PAR, LAI, kb,
        diff_frac, lat, hour, n_day, x_l,
        alpha, tau, alpha_soil_sat, alpha_soil_dry, theta0
    )

    f_temp = fT(fmin, Ts, Tmax, Topt, Tmin)

    f_vpd = fVPD(Ts, RH, k, d)

    f_sw = betat(sm, sm_wilt, sm_crit)

    # Combined environmental response
    f_env = np.maximum(fmin, f_temp * f_vpd * f_sw)

    # Sunlit and shaded leaf area
    L_sun = LAI_sun(kb, LAI)
    L_sha = LAI_sha(kb, LAI)

    # Canopy-integrated stomatal conductance
    g_sun = gmax * f_par_sun * f_env * L_sun * molar_volume(Ts) * 1e-3
    g_sha = gmax * f_par_sha * f_env * L_sha * molar_volume(Ts) * 1e-3

    return g_sun, g_sha

#------------------------------------
#------------------------------------
#
#   GEOS-Chem
#
#------------------------------------
#------------------------------------
#
# Calculates the stomatal conductance response to environmental
# conditions using temperature, PAR response functions.
#
# References:
# https://geos-chem.readthedocs.io/en/14.3.1/
#
# Units:
#   Stomatal resistance RIX: s m-1
#   Temperature:          K
#   PAR:                  W m-2
#   LAI:                  m2 leaf m-2 ground
#
# requires GEOS-Chem parameters from Olson_2001_Drydep_Inputs.nc
#
#------------------------------------

def suncos(lat, n_day, hour):
    """
    Calculate cosine of solar zenith angle.

    Parameters
    ----------
    lat : float or array
        Latitude (degrees, positive north).
    n_day : float or array
        Day of year (1-365/366).
    hour : float or array
        Local solar time (decimal hours, 0-24).

    Returns
    -------
    cos_SZA : float or ndarray
        Cosine of solar zenith angle (dimensionless).
    """

    lat_rad = np.deg2rad(lat)

    # Solar declination
    declin = decl(n_day)

    # Solar hour angle (radians)
    hour_angle = np.deg2rad(15 * (np.asarray(hour) - 12))

    # Cosine of solar zenith angle
    cos_SZA = (
        np.sin(lat_rad) * np.sin(declin)
        + np.cos(lat_rad) * np.cos(declin) * np.cos(hour_angle)
    )

    # Set invalid values to 0
    cos_SZA = np.where(np.isfinite(cos_SZA), cos_SZA, 0)

    # Below the horizon
    return np.maximum(cos_SZA, 1e-10)

def sunparam(x):
    """Equivalent of SUNPARAM_R8"""
    x = np.asarray(x, dtype=np.float64).copy()

    ND = np.array([55.0, 20.0, 11.0], dtype=np.float64)
    X0 = np.array([11.0, 1.0, 1.0], dtype=np.float64)

    for i in range(3):
        # Upper bound
        x[i] = min(x[i], X0[i])

        # Lower bound
        if i != 2:      # LAI and SUNCOS
            xlow = X0[i] / ND[i]
        else:           # Cloud fraction
            xlow = 0.0

        x[i] = max(x[i], xlow)

        # Normalize
        x[i] /= X0[i]

    return x


def biofit(xlai, lat, n_day, hour, cfrac, drycoeff):
    """
    Equivalent of BIOFIT_R8.

    Parameters
    ----------
    xlai : float or array
        Leaf area index (m2 m-2).
    lat : float or array
        Latitude (degrees, positive north).
    n_day : float or array
        Day of year.
    hour : float or array
        Local solar time (decimal hours, 0-24).
    cfrac : float or array
        Cloud fraction (dimensionless).
    drycoeff : array
        Polynomial fitting coefficients.

    Returns
    -------
    bio_fit : float or ndarray
        Biogenic fitting factor (dimensionless).
    """

    # Calculate cosine of solar zenith angle
    sun_cos = suncos(lat, n_day, hour)

    # TERM array in Fortran: [1, XLAI, SUNCOS, CFRAC]
    term = np.stack(
        np.broadcast_arrays(1.0, xlai, sun_cos, cfrac),
        axis=0
    ).astype(np.float64)

    # Apply SUNPARAM_R8 to TERM(2:4)
    term[1:] = sunparam(term[1:])

    # Build REALTERM
    KK = 4
    realterm = []

    for k3 in range(KK):
        for k2 in range(k3, KK):
            for k1 in range(k2, KK):
                realterm.append(term[k1] * term[k2] * term[k3])

    realterm = np.array(realterm, dtype=np.float64)

    # Polynomial evaluation
    bio_fit = np.tensordot(drycoeff, realterm, axes=(0, 0))

    # Enforce minimum value
    bio_fit = np.maximum(bio_fit, 0.1)

    return bio_fit

def gs_GC(RIX, TEMP, LAI, RAD0, lat, n_day, hour, CFRAC, drycoeff, D=0.67):
    """
    Calculate temperature and light adjusted stomatal resistance.

    Parameters
    ----------
    TEMP : float
        Surface air temperature (K).
    LAI : float
        Leaf area index.
    RAD0 : float
        Radiation at surface.
    SUNCOS : float
        Solar zenith angle cosine.
    CFRAC : float
        Cloud fraction.

    Returns
    -------
    float
        Adjusted stomatal resistance (RIX).
    """

    # Surface temperature
    TEMPK = TEMP
    TEMPC = TEMP - 273.15

    if RIX < 9999:

        # Temperature correction factor
        GFACT = 100.0

        if 0 <= TEMPC <= 40:
            GFACT = 400.0 / TEMPC / (40.0 - TEMPC)

        # Biological/light correction factor
        GFACI = 100.0

        if RAD0 > 0 and LAI > 0:

            GFACI = 1.0 / biofit(LAI,  lat, n_day, hour, CFRAC, drycoeff)

        # Apply corrections
        RIX = RIX * GFACT * GFACI * 1 / D

    return 1 / RIX

#------------------------------------
#------------------------------------
#
#   Non-stomatal conductances
#
#------------------------------------
#------------------------------------

"""
Parameterisations of non-stomatal ozone deposition to vegetation
cuticles, soil and lower-canopy surfaces.

The module contains alternative schemes based on Zhou (2017),
Clifton (2020, 2021), Zhang, and the GEOS-Chem
Wesely-based resistance formulation.

Conventions
-----------
Temperature:
    K (unless explicitly stated otherwise).

Relative humidity:
    % (0-100).

Leaf area index (LAI):
    m2 m-2.

Friction velocity (ustar):
    m s-1.

Wind and canopy height:
    m s-1 and m, respectively.

Resistance:
    s m-1, where the underlying parameterisation defines
    a deposition resistance.

Conductance:
    m s-1.

Soil moisture:
    Volumetric soil moisture (m3 m-3)
    OR
    Dimensionless fractional wetness (0-1).

"""


#------------------------------------
# ZHOU ET AL. (2017)
#-----------------------------------

def Zhou_gcut(f_wet, rws= 2e3, rcut= 1e5):
    """
    Calculate the effective cuticular resistance using the
    Zhou (2017) wet and dry surface formulation.

    Wet and dry cuticular resistances are combined in parallel,
    weighted by the fraction of wet surface.

    Parameters
    ----------
    f_wet : float or array_like
        Fraction of wet cuticular surface (dimensionless).
    rws : float
        Resistance of the wet cuticular surface (s m-1).
    rcut : float
        Resistance of the dry cuticular surface (s m-1).

    Returns
    -------
    float or numpy.ndarray
        Cuticular conductance (m s-1).
    """
    g_tot = f_wet / rws + (1.0 - f_wet) / rcut

    return  g_tot


#-----------------------------------
# CLIFTON ET AL. (2020)
#----------------------------------- 

def OC20_fT(T, wet):
    """
    Calculate the temperature-dependent scaling factor for
    non-stomatal deposition following Clifton et al. (2020).

    Parameters
    ----------
    T : float or array_like
        Surface temperature (K).
    wet : bool or int
        Surface wetness flag:
            0 : dry surface
            1 : wet surface

    Returns
    -------
    float or numpy.ndarray
        Temperature scaling factor (dimensionless).

    Notes
    -----
    The temperature sensitivity coefficient is 0.9 for wet
    surfaces and 0.1 for dry surfaces.

    The scaling factor has a minimum value of 1.
    """
    T_C = np.asarray(T, dtype=float) - 273.15

    c = np.where(np.asarray(wet) == 1, 0.9, 0.1)

    return np.maximum(np.exp(-c * (T_C - 5.0)), 1.0)


def OC20_gcut(T, LAI, RH, wet, rdry=6000, rwet=400):
    """
    Calculate the cuticular ozone deposition resistance
    following Clifton et al. (2020).

    The dry-surface resistance depends on LAI and relative
    humidity. The wet-surface resistance depends on LAI.
    Both are modified by a temperature-dependent scaling factor.

    Parameters
    ----------
    T : float or array_like
        Surface temperature (K).
    LAI : float or array_like
        Leaf area index (m2 m-2).
    RH : float or array_like
        Relative humidity (%).
    wet : bool or int
        Surface wetness flag:
            0 : dry surface
            1 : wet surface
    rdry : float
        Empirical dry cuticular resistance parameter (s m-1).
    rwet : float
        Empirical wet cuticular resistance parameter (s m-1).

    Returns
    -------
    float or numpy.ndarray
        Cuticular conductance (m s-1).
    """
    s_T = OC20_fT(T, wet)

    R_dry = rdry / (LAI * np.exp(np.asarray(RH) / 100.0))
    R_wet = rwet / LAI

    R_cut = np.where(np.asarray(wet) == 1, R_wet, R_dry)

    return 1.0 / (R_cut * s_T)


def OC20_gsoil(Ts, wet):
    """
    Calculate the soil ozone deposition resistance following
    Clifton et al. (2020).

    The resistance depends on soil surface wetness and
    temperature.

    Parameters
    ----------
    Ts : float or array_like
        Soil surface temperature (K).
    wet : bool or int
        Soil wetness flag:
            0 : dry soil
            1 : wet soil

    Returns
    -------
    float or numpy.ndarray
        Soil ozone deposition resistance (s m-1).

    Notes
    -----
    The base resistance is:
        200 s m-1 for dry soil
        500 s m-1 for wet soil

    """
    Ts = np.asarray(Ts, dtype=float)

    R_soil = np.where(np.asarray(wet) == 1, 500.0, 200.0)

    s_T = OC20_fT(Ts, wet)

    return 1.0 / (R_soil * s_T)


def OC20_gac(h, ustar, LAI):
    """
    Calculate the aerodynamic resistance term used in the
    Clifton et al. (2020) formulation.

    Parameters
    ----------
    h : float or array_like
        Canopy height (m).
    ustar : float or array_like
        Friction velocity (m s-1).
    LAI : float or array_like
        Leaf area index (m2 m-2).

    Returns
    -------
    float or numpy.ndarray
        Aerodynamic resistance term.

    """
    return 1.0 / (14.0 * LAI * h / ustar)


#----------------------------------- 
# CLIFTON ET AL. (2021)
#----------------------------------- 

def OC21_gcut(RH, LAI, R_cut=2e3):
    """
    Calculate cuticular ozone deposition resistance following
    Clifton et al. (2021).

    The cuticular conductance increases exponentially with
    relative humidity and linearly with leaf area index.

    Parameters
    ----------
    RH : float or array_like
        Relative humidity (%).
    R_cut : float
        Reference cuticular resistance parameter (s m-1).
    LAI : float or array_like
        Leaf area index (m2 m-2).

    Returns
    -------
    float or numpy.ndarray
        Cuticular conductance (m s-1).
    """
    g_tot = LAI * np.exp(np.asarray(RH) / 100.0) / R_cut

    return g_tot


def OC21_gsoil(sm, Rsoil = 1500):
    """
    Calculate soil ozone deposition resistance following
    Clifton et al. (2021).

    Soil moisture is used as a proxy for the fraction of wet
    soil surface.

    Parameters
    ----------
    sm : float or array_like
        Fractional soil wetness (dimensionless, 0-1).
    Rsoil : float
        Reference soil resistance parameter (s m-1).

    Returns
    -------
    float or numpy.ndarray
        Soil ozone conductance (m s-1).

    """
    g_tot = 1.0 / (np.asarray(sm, dtype=float) * Rsoil)

    return g_tot



#----------------------------------- 
# ZHANG ET AL. 2002
#----------------------------------- 

def Zhang_gcut(RH, LAI, ustar, wet, rcutd0 = 6e3, rcutw0 = 4e2):
    """
    Calculate cuticular ozone deposition resistance following
    the Zhang parameterisation.

    Separate resistance relationships are used for wet and
    dry cuticular surfaces.

    Parameters
    ----------
    RH : float or array_like
        Relative humidity (%).
    LAI : float or array_like
        Leaf area index (m2 m-2).
    ustar : float or array_like
        Friction velocity (m s-1).
    rcutw0 : float
        Reference wet cuticular resistance parameter.
    rcutd0 : float
        Reference dry cuticular resistance parameter.
    wet : bool or int
        Surface wetness flag:
            0 : dry surface
            1 : wet surface

    Returns
    -------
    float or numpy.ndarray
        Cuticular conductance (m s-1).

    """
    RH = np.asarray(RH, dtype=float)

    R_wet = rcutw0 / (np.sqrt(LAI) * ustar)

    R_dry = rcutd0 / (
        np.exp(0.03 * RH) * np.asarray(LAI)**0.25 * ustar
    )
    
    R = np.where(np.asarray(wet) == 1, R_wet, R_dry)
    
    return 1.0 / R

def Zhang_gsoil(ustar, LAI, tsoil, Rac0=250, Rg0=200, Rsnow=2000):
    """
    Calculate soil ozone deposition conductance following
    the Zhang parameterisation.

    Soil and snow deposition pathways are calculated separately,
    with the selected pathway determined by soil temperature.

    Parameters
    ----------
    Rac0 : float
        Reference aerodynamic resistance parameter.
    ustar : float or array_like
        Friction velocity (m s-1).
    LAI : float or array_like
        Leaf area index (m2 m-2).
    Rg0 : float
        Reference soil resistance parameter (s m-1).
    Rsnow : float
        Reference snow resistance parameter (s m-1).
    tsoil : float or array_like
        Soil temperature (K).

    Returns
    -------
    float or numpy.ndarray
        Soil/snow ozone deposition conductance (m s-1).

    Notes
    -----
    Snow deposition is selected when tsoil <= 274 K.
    """
    R_a = Rac0 * ustar**-2 * np.asarray(LAI)**0.25

    g_soil = 1.0 / (R_a + Rg0)
    g_snow = 1.0 / (R_a + Rsnow)

    return np.where(np.asarray(tsoil) <= 274.0, g_snow, g_soil)


#----------------------------------- 
# GEOS-CHEM
#----------------------------------- 

def GC_fT(Ts):
    """
    Calculate the temperature-dependent resistance term used
    in the GEOS-Chem non-stomatal deposition formulation.

    Parameters
    ----------
    Ts : float or array_like
        Surface temperature (K).

    Returns
    -------
    float or numpy.ndarray
        Empirical temperature-dependent resistance term.

    """
    T_C = np.asarray(Ts, dtype=float) - 273.15

    return 1000.0 * np.exp(-T_C - 4.0)


def RLU_GC(IRLU, T, LAI):
    """
    Calculate the upper-canopy cuticular resistance term used
    in the GEOS-Chem formulation.

    Parameters
    ----------
    IRLU : float or array_like
        Reference resistance parameter for the upper canopy (s m-1).
    T : float or array_like
        Surface temperature (K).
    LAI : float or array_like
        Leaf area index (m2 m-2).

    Returns
    -------
    float or numpy.ndarray
        Upper-canopy conductance (s m-1).

    """
    H = 0.01

    R_LU = (IRLU / LAI) + GC_fT(T)

    lower_term = H / 1e5 + 1.0

    return R_LU / lower_term


def GC_gsoil(Ts, RGSO):
    """
    Calculate the GEOS-Chem soil deposition term.

    Parameters
    ----------
    Ts : float or array_like
        Soil temperature (K).

    Returns
    -------
    float or numpy.ndarray
        Soil resistance (s m-1).

    """

    R_full = RGSO + GC_fT(Ts)

    return 1.0 / R_full


def sol_G(lat, n_day, hour):
    """
    Calculate the empirical solar radiation term used in
    the Wesely-based non-stomatal deposition formulation.

    Parameters
    ----------
    theta : float or array_like
        Solar zenith angle (degrees).

    Returns
    -------
    float or numpy.ndarray
        Estimated solar radiation (W m-2).

    Notes
    -----
    The original empirical relationship is retained:
        I0 = 1.353 * 1000
        I = I0 * 0.7**(AM**0.678)

    where AM is the relative optical air mass.
    """

    # Prevent division by zero at the horizon and below it.
    sun_cos = suncos(lat, n_day, hour)

    AM = 1.0 / sun_cos

    I0 = 1.353 * 1000.0

    return I0 * 0.7**(AM**0.678)


def RDC_GC(lat=1, n_day=180, hour=12):
    """
    Calculate the radiation-dependent canopy resistance.

    Parameters
    ----------
    theta : float or array_like
        Solar zenith angle (degrees).

    Returns
    -------
    float or numpy.ndarray
        Radiation-dependent resistance.

    Notes
    -----
    The original empirical relationship is retained:
        RDC = 100 * (1 + 1000 / (G + 10))

    where G is the estimated solar radiation (W m-2).
    """
    G = sol_G(lat, n_day, hour)

    G_term = 1000.0 / (G + 10.0)

    return (100.0 * (1.0 + G_term))


def RLOW_GC(Ts, IRCLO):
    """
    Calculate the temperature-dependent lower-canopy
    resistance (e.g. stems and trunks) in the Wesely-based
    GEOS-Chem formulation.

    Parameters
    ----------
    Ts : float or array_like
        Surface temperature (K).

    Returns
    -------
    float or numpy.ndarray
        Lower-canopy resistance term.
    """
    R_full = IRCLO + GC_fT(Ts)

    return R_full


def GC_gcut(LAI, IRCLO, IRLU, T, lat=1, n_day=180, hour=12):
    """
    Calculate the combined lower-canopy and soil deposition
    conductance in the GEOS-Chem formulation.

    Parameters
    ----------
    gac : float or array_like
        Aerodynamic term passed to GC_soil. 
    theta : float or array_like
        Solar zenith angle (degrees).
    Ts : float or array_like
        Surface temperature (K).

    Returns
    -------
    float or numpy.ndarray
        Combined lower-canopy and soil conductance term.

    Notes
    -----
    The lower-canopy conductance is calculated from the sum
    of radiation-dependent and temperature-dependent
    resistances. The soil term is calculated separately.
    """
    g_lowerc = 1.0 / (RDC_GC(lat, n_day, hour) + RLOW_GC(T, IRCLO))

    g_cut = 1.0 / RLU_GC(IRLU, T, LAI)

    return (g_lowerc + g_cut)


#----------------------------------- 
# SNOW COVER
#----------------------------------- 

def f_snow(gsoil, tsoil, Rsnow=7000):
    """
    Select the soil or snow deposition resistance based on
    soil temperature.

    Parameters
    ----------
    gsoil : float or array_like
        Soil deposition conductance (s m-1).
    tsoil : float or array_like
        Soil temperature (K).
    Rsnow : float
        Snow deposition resistance (s m-1).

    Returns
    -------
    float or numpy.ndarray
        Effective soil/snow deposition conductance (m s-1).

    Notes
    -----
    Snow conductance is selected when tsoil <= 274 K.
    """
    return np.where(np.asarray(tsoil) <= 274.0, 1/Rsnow, gsoil)


#----------------------------------- 
# TEMPERATURE AND SOIL-MOISTURE DEPENDENT SOIL DEPOSITION
#----------------------------------- 

def gsoil_fitted(X, Topt=6.935, sm_max=1.836, Rmax=310.179,
         Rsnow=7000.0):
    """
    Calculate temperature- and soil-moisture-dependent soil
    ozone deposition conductance.

    Soil resistance is modified according to soil temperature,
    relative humidity and soil moisture.

    Parameters
    ----------
    X : tuple
        Tuple containing:
            sm : float or array_like
                Soil moisture (dimensionless, as used by the
                original parameterisation).
            tsoil : float or array_like
                Soil temperature (K).
            RH : float or array_like
                Relative humidity (%).

    Topt : float, optional
        Reference temperature scaling parameter (degrees C).
        Default is 6.935.
    sm_max : float, optional
        Reference maximum soil moisture parameter
        (dimensionless). Default is 1.836.
    Rmax : float, optional
        Maximum/reference soil resistance parameter (s m-1).
        Default is 310.179.
    Rsnow : float, optional
        Snow deposition resistance (s m-1).
        Default is 7000.

    Returns
    -------
    float or numpy.ndarray
        Soil/snow ozone deposition conductance (m s-1).

    """
    sm, tsoil, RH = X

    T_C = np.asarray(tsoil, dtype=float) - 273.15

    ft = T_C / Topt
    ft = np.minimum(ft, 1.0)

    fsm = 1.0 - np.asarray(sm, dtype=float) / sm_max
    fsm = np.maximum(fsm, 0.0)

    RH_factor = np.exp(np.asarray(RH, dtype=float) / 100.0)

    R_soil = Rmax / (RH_factor * ft * fsm)

    R_effective = np.where(T_C <= 1.0, Rsnow, R_soil)

    return 1.0 / R_effective

